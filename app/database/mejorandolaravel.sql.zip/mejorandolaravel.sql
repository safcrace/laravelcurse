-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 09-07-2014 a las 05:22:15
-- Versión del servidor: 5.6.12-log
-- Versión de PHP: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `mejorandolaravel`
--
CREATE DATABASE IF NOT EXISTS `mejorandolaravel` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `mejorandolaravel`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `candidates`
--

DROP TABLE IF EXISTS `candidates`;
CREATE TABLE IF NOT EXISTS `candidates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `website_url` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `job_type` enum('full','partial','freelance') NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `available` tinyint(1) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `candidates_category_id_foreign` (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=81 ;

--
-- Volcado de datos para la tabla `candidates`
--

INSERT INTO `candidates` (`id`, `website_url`, `description`, `job_type`, `category_id`, `available`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'http://hudson.com/', 'Voluptatibus mollitia placeat aut dolorem. At laboriosam quidem harum rerum. Facilis iusto quo sint iusto et tenetur ut beatae. Perspiciatis pariatur sed qui commodi.', 'partial', 3, 1, 'dr-kellen-kovacek-v', '2014-07-09 11:15:13', '2014-07-09 11:15:13'),
(2, 'http://www.smith.com/', 'Impedit aut quia sapiente dolor. Odit iusto culpa sint saepe omnis. Et quia hic quia. Est voluptas at unde voluptatem occaecati saepe.', 'full', 1, 1, 'karianne-smith-md', '2014-07-09 11:15:13', '2014-07-09 11:15:13'),
(3, 'http://www.bartoletti.com/', 'Repellendus molestias itaque tempore eveniet at voluptatem quod. Assumenda esse quisquam atque aspernatur quis. Nobis quibusdam accusantium inventore sint nulla qui et.', 'full', 3, 1, 'tremaine-jacobson', '2014-07-09 11:15:14', '2014-07-09 11:15:14'),
(4, 'http://www.vonschulist.biz/', 'Sit omnis accusantium possimus id laboriosam temporibus. Sed dolorum totam mollitia temporibus odio. Ea dolorem beatae hic.', 'full', 3, 1, 'ms-minnie-brakus-dds', '2014-07-09 11:15:14', '2014-07-09 11:15:14'),
(5, 'http://hoppedavis.info/', 'Sed tempora aut quidem optio officia et natus a. Minus animi vel esse quam occaecati. Cum quae aut et ut dicta. Quisquam nam iusto molestias ipsum odio.', 'freelance', 1, 1, 'ms-jay-marvin', '2014-07-09 11:15:15', '2014-07-09 11:15:15'),
(6, 'http://gutkowskiwill.com/', 'Sit assumenda ut et nam. Alias aliquid non repellendus placeat nostrum reiciendis. Aut voluptatem voluptas sit rem.', 'partial', 1, 1, 'mrs-walker-metz-v', '2014-07-09 11:15:15', '2014-07-09 11:15:15'),
(7, 'http://www.monahankuhlman.com/', 'Est sit autem enim dicta. Error officia quaerat alias est et. Hic ipsum accusamus eos sapiente.', 'partial', 3, 1, 'chandler-champlin', '2014-07-09 11:15:15', '2014-07-09 11:15:15'),
(8, 'http://cremin.org/', 'Quasi esse suscipit quia deleniti dolorum. Repellat iusto atque vero.', 'full', 1, 1, 'aric-ritchie-v', '2014-07-09 11:15:15', '2014-07-09 11:15:15'),
(9, 'http://oberbrunnermurphy.com/', 'Deserunt consequuntur autem ab neque voluptas facilis. Voluptates perferendis eos exercitationem et perferendis odit est. Iste est illum non aut tempore aut nam.', 'full', 2, 1, 'isai-hamill', '2014-07-09 11:15:16', '2014-07-09 11:15:16'),
(10, 'http://friesenullrich.com/', 'Voluptatem dolore corporis et qui soluta eligendi. Deserunt veritatis facere earum esse. Dolor vel perferendis nemo in eum ipsam recusandae. Qui aut quod debitis et est quia.', 'partial', 3, 1, 'miss-bradley-witting-sr', '2014-07-09 11:15:16', '2014-07-09 11:15:16'),
(11, 'http://www.senger.net/', 'Ut dicta doloribus id sed quam quis molestiae. Accusamus maiores ipsa molestiae eos ratione et velit. Est sed qui accusantium nam voluptatem blanditiis temporibus.', 'freelance', 3, 1, 'mollie-baumbach', '2014-07-09 11:15:16', '2014-07-09 11:15:16'),
(12, 'http://www.koch.com/', 'Occaecati expedita neque quisquam quam modi. Quia vel nulla iusto eius molestiae accusamus dolores. Adipisci aut aspernatur eius est molestias.', 'freelance', 2, 1, 'keaton-graham', '2014-07-09 11:15:16', '2014-07-09 11:15:16'),
(13, 'http://rennervon.com/', 'Quis consequatur aut rerum ad non placeat velit. Velit et impedit expedita voluptas. Consequatur aut id totam. Quo accusamus et explicabo earum.', 'partial', 1, 1, 'houston-bayer', '2014-07-09 11:15:17', '2014-07-09 11:15:17'),
(14, 'http://www.bahringer.com/', 'Distinctio error consectetur aut odit veritatis. Sequi quia qui ea dolor delectus qui. Nostrum quidem veritatis id occaecati.', 'full', 3, 1, 'victoria-waters', '2014-07-09 11:15:17', '2014-07-09 11:15:17'),
(15, 'http://www.windler.com/', 'Explicabo repellat possimus recusandae. Rerum vel eaque enim quis maiores. Nihil ipsum dolores in natus veniam explicabo.', 'freelance', 1, 1, 'dr-javon-johns', '2014-07-09 11:15:17', '2014-07-09 11:15:17'),
(16, 'http://howetromp.org/', 'Veniam facilis reprehenderit odit illo veritatis. Rem maiores dignissimos amet sint beatae. Aperiam molestiae dolorem amet et fuga accusamus autem ducimus. Velit harum nisi fugit consequuntur earum.', 'partial', 2, 1, 'annabel-cummings', '2014-07-09 11:15:17', '2014-07-09 11:15:17'),
(17, 'http://kemmerbednar.com/', 'Dolores quia est deleniti qui necessitatibus. Sed debitis recusandae quia quia blanditiis qui. Nihil et mollitia voluptatem alias ut eveniet.', 'full', 1, 1, 'onie-erdman-jr', '2014-07-09 11:15:18', '2014-07-09 11:15:18'),
(18, 'http://douglastorphy.info/', 'Et aut atque reprehenderit quibusdam eos et. Sit eligendi id quia reprehenderit odio est amet. Ad iure id sint at.\nQuae est iure nemo. Vero qui est laudantium. Rem praesentium aut in officia nisi.', 'freelance', 3, 1, 'rosetta-legros', '2014-07-09 11:15:18', '2014-07-09 11:15:18'),
(19, 'http://farrell.net/', 'Est eligendi aut non aut. Ratione omnis quam quasi hic quisquam. Placeat expedita cupiditate dolor vel voluptatibus cupiditate. Deleniti consequatur et laudantium molestias quia.', 'partial', 2, 1, 'mr-jeffery-sanford-dds', '2014-07-09 11:15:18', '2014-07-09 11:15:18'),
(20, 'http://willswaniawski.org/', 'Sint explicabo asperiores tempora aut ea repudiandae. Veritatis natus quod molestiae vel aut officiis. Consectetur omnis blanditiis qui commodi. Aliquam ut tempora natus nulla.', 'freelance', 2, 1, 'norbert-koepp', '2014-07-09 11:15:18', '2014-07-09 11:15:18'),
(21, 'http://witting.net/', 'Aut soluta incidunt laborum accusamus. Omnis sit ut deserunt non. Vel sint architecto hic officia. Qui facere sed repudiandae eos sed rerum et.', 'full', 3, 1, 'misael-murray-i', '2014-07-09 11:15:19', '2014-07-09 11:15:19'),
(22, 'http://www.kuhic.com/', 'Totam id unde in voluptates vel veniam totam. Sequi enim quae quo dolorum quo maiores occaecati magnam. Et quae est vel dicta sed accusamus.', 'partial', 1, 1, 'dr-shaina-wunsch-v', '2014-07-09 11:15:19', '2014-07-09 11:15:19'),
(23, 'http://nikolauskonopelski.com/', 'Optio doloremque aut velit sit. Soluta iusto labore ex. Velit voluptatem vitae aut tempora perspiciatis rerum deserunt.', 'freelance', 3, 1, 'london-blick', '2014-07-09 11:15:19', '2014-07-09 11:15:19'),
(24, 'http://macejkovic.org/', 'Culpa porro quisquam veniam quis. Commodi molestiae consequatur laudantium ratione eveniet. Occaecati et aliquid aut deserunt fugiat.', 'full', 3, 1, 'mr-janis-spencer-v', '2014-07-09 11:15:19', '2014-07-09 11:15:19'),
(25, 'http://bauch.biz/', 'Quo quas occaecati quo ducimus corrupti soluta reprehenderit aut. Consequatur possimus illo ipsum asperiores quidem aliquid dolore. Corporis voluptas sint enim repudiandae qui.', 'partial', 3, 1, 'ms-jamel-sipes-v', '2014-07-09 11:15:20', '2014-07-09 11:15:20'),
(26, 'http://www.grantbotsford.com/', 'Facere quia aut unde quia ut aspernatur omnis. Fugiat quis esse sed corrupti mollitia.', 'partial', 1, 1, 'moses-schaden', '2014-07-09 11:15:20', '2014-07-09 11:15:20'),
(27, 'http://www.kuvalisschaefer.com/', 'Qui veniam maxime nobis doloremque. Optio repellat error voluptatum quaerat dolorum exercitationem sunt adipisci. Eius mollitia repellendus sed qui asperiores sapiente architecto qui.', 'partial', 3, 1, 'geovanny-pacocha', '2014-07-09 11:15:20', '2014-07-09 11:15:20'),
(28, 'http://raynor.net/', 'Sed iure quisquam debitis voluptatem. Blanditiis eos minima occaecati et.', 'freelance', 1, 1, 'miss-celestino-pacocha-ii', '2014-07-09 11:15:20', '2014-07-09 11:15:20'),
(29, 'http://www.jerdehegmann.com/', 'Sit voluptatum tenetur neque quos. Sunt autem exercitationem architecto necessitatibus. Exercitationem quas eos ut et est tenetur. Atque ut molestiae tenetur laboriosam.', 'full', 1, 1, 'karina-kessler-md', '2014-07-09 11:15:21', '2014-07-09 11:15:21'),
(30, 'http://ortizgreenfelder.biz/', 'Unde enim expedita velit. Unde temporibus voluptatem praesentium sunt et. In autem ratione molestiae illo neque commodi fuga.', 'partial', 3, 1, 'franz-schumm', '2014-07-09 11:15:21', '2014-07-09 11:15:21'),
(31, 'http://eichmannkshlerin.org/', 'Repellendus eos nihil ut. Eaque quia quis sit voluptas. Doloremque nihil facere consequatur error ex et.', 'full', 1, 1, 'paul-borer-sr', '2014-07-09 11:15:21', '2014-07-09 11:15:21'),
(32, 'http://www.dubuqueferry.com/', 'Quibusdam quis qui blanditiis. Dolores ullam sit quaerat fugiat aperiam possimus. Id est qui aspernatur eos placeat accusantium qui. Delectus repellat tenetur repellat porro similique dolore modi.', 'partial', 1, 1, 'dr-hassie-herman', '2014-07-09 11:15:21', '2014-07-09 11:15:21'),
(33, 'http://medhurstparisian.info/', 'Error nostrum nam velit iusto dolores voluptate. Magni perspiciatis laborum maiores doloremque ducimus incidunt voluptatibus. Sunt provident libero non in natus officia iure.', 'full', 3, 1, 'franco-roberts', '2014-07-09 11:15:22', '2014-07-09 11:15:22'),
(34, 'http://ratke.org/', 'Rerum illum molestias molestias velit. Quia rerum deserunt laboriosam qui sit quae. Est necessitatibus quas sit et fuga dolores aut aliquid.', 'partial', 2, 1, 'pansy-reilly', '2014-07-09 11:15:22', '2014-07-09 11:15:22'),
(35, 'http://www.jenkins.biz/', 'Blanditiis ex voluptatem facere. Quod quia similique ad voluptate ad aut. Sunt quos ipsa illo. Est eligendi voluptate quod debitis.', 'partial', 1, 1, 'giovanny-swaniawski', '2014-07-09 11:15:22', '2014-07-09 11:15:22'),
(36, 'http://www.welch.com/', 'Doloremque minima ratione vel. Autem itaque voluptatem dolores et. Est aliquam magnam culpa quam repudiandae dolorem. Corrupti corporis architecto atque.', 'partial', 2, 1, 'alfred-berge', '2014-07-09 11:15:23', '2014-07-09 11:15:23'),
(37, 'http://www.pricezemlak.net/', 'Consectetur qui nihil et. Temporibus voluptates cum atque voluptas aperiam. Velit enim fuga quis eius eum earum.', 'full', 1, 1, 'maegan-ryan', '2014-07-09 11:15:23', '2014-07-09 11:15:23'),
(38, 'http://www.sporerwill.biz/', 'Aperiam nulla veniam recusandae quis sint voluptatibus. Quo molestiae asperiores porro quod. Suscipit dolorum ratione voluptatem ducimus. Minima id natus aspernatur ut est culpa est.', 'freelance', 1, 1, 'ms-kristian-wolff-iii', '2014-07-09 11:15:23', '2014-07-09 11:15:23'),
(39, 'http://www.weberzboncak.com/', 'Fugit nam nobis vitae rerum ratione autem. Consequatur tempora totam distinctio qui. Eius et dignissimos libero odit suscipit quis et.', 'partial', 1, 1, 'adonis-kunde', '2014-07-09 11:15:23', '2014-07-09 11:15:23'),
(40, 'http://www.sporerschultz.net/', 'Est amet libero non minus libero laboriosam. Est perferendis odit quia architecto. Consequatur quo eligendi non qui et magnam. Assumenda et a facilis est ducimus laudantium voluptate.', 'full', 2, 1, 'jordi-crona', '2014-07-09 11:15:24', '2014-07-09 11:15:24'),
(41, 'http://www.okeefe.com/', 'Voluptate dolore ipsum doloremque et qui incidunt. Culpa et cupiditate natus vero consequatur voluptatem accusantium magni. Nihil perspiciatis aut vel eaque.', 'full', 1, 1, 'mrs-reyna-beahan', '2014-07-09 11:15:24', '2014-07-09 11:15:24'),
(42, 'http://www.zemlak.com/', 'Deserunt molestiae eveniet veritatis cumque dolores dolorem. Enim voluptatibus occaecati consequatur illo placeat rerum. Fugit ipsam veniam ab repellat.', 'freelance', 2, 1, 'blake-morar', '2014-07-09 11:15:24', '2014-07-09 11:15:24'),
(43, 'http://orn.com/', 'In aut omnis dignissimos. Quis blanditiis soluta nisi debitis. Quo sit et nisi dolorem similique hic. Tenetur ipsa et sunt iure dolor perspiciatis quidem.', 'freelance', 1, 1, 'golden-dach-jr', '2014-07-09 11:15:24', '2014-07-09 11:15:24'),
(44, 'http://www.brekke.info/', 'Nulla iure error minima harum quaerat. Recusandae fuga nisi asperiores pariatur expedita aut officiis. Debitis asperiores eum eum illum qui.', 'full', 3, 1, 'vern-davis', '2014-07-09 11:15:25', '2014-07-09 11:15:25'),
(45, 'http://jaskolski.com/', 'Nesciunt nam et odit autem rerum ut magni. Nam et cum modi. Eos at inventore vel laudantium quia modi repellendus.', 'partial', 3, 1, 'taurean-metz', '2014-07-09 11:15:25', '2014-07-09 11:15:25'),
(46, 'http://www.bogan.net/', 'Vitae qui voluptatem itaque est illum pariatur est qui. Qui corporis magnam ex molestiae nesciunt sit ab. Dolor rerum porro magni totam fugiat.', 'freelance', 2, 1, 'mr-chadrick-ohara', '2014-07-09 11:15:25', '2014-07-09 11:15:25'),
(47, 'http://www.mayert.info/', 'Qui et earum unde ut assumenda a. Labore soluta est et voluptatibus recusandae maiores necessitatibus. Ipsa dolorem eligendi et natus repudiandae hic temporibus in.', 'freelance', 2, 1, 'dr-adelle-funk', '2014-07-09 11:15:26', '2014-07-09 11:15:26'),
(48, 'http://stoltenberg.com/', 'Officiis nam iure molestiae perspiciatis quidem. Quod quaerat dicta quia non cum veniam. At ut architecto fugiat tempora. Excepturi facilis aperiam ipsam nulla minus. Sunt et sed accusamus ipsa.', 'partial', 3, 1, 'lillian-witting', '2014-07-09 11:15:26', '2014-07-09 11:15:26'),
(49, 'http://kemmer.info/', 'Repellendus cupiditate animi quaerat expedita quidem omnis. Quasi esse quod nesciunt at molestias. Sed non qui minus soluta voluptatibus amet in fugit.', 'full', 1, 1, 'sharon-eichmann', '2014-07-09 11:15:26', '2014-07-09 11:15:26'),
(50, 'http://koelpin.biz/', 'Eum minus aliquam nam nemo aut. Est nesciunt molestiae amet nam excepturi animi sed sit. Perspiciatis temporibus non et sequi beatae dolorem aut.', 'partial', 3, 1, 'dr-charity-towne', '2014-07-09 11:15:26', '2014-07-09 11:15:26'),
(51, 'http://www.ledner.org/', 'Culpa molestiae inventore dolorem voluptas temporibus blanditiis. Necessitatibus rerum voluptatem veritatis consequuntur vel temporibus est et. Est architecto unde numquam recusandae nulla ut et.', 'partial', 1, 1, 'hortense-murphy', '2014-07-09 11:15:27', '2014-07-09 11:15:27'),
(52, 'http://ryan.com/', 'Accusamus iusto neque voluptas sunt repellendus voluptas ea. Magni quisquam tempora cum omnis culpa animi dolorem.', 'full', 3, 1, 'elmer-windler', '2014-07-09 11:15:27', '2014-07-09 11:15:27'),
(53, 'http://schuppe.org/', 'Occaecati animi dignissimos vel eveniet. Ea placeat aut et alias sed maiores. Adipisci voluptatum maiores voluptas non ad.', 'partial', 1, 1, 'jefferey-schinner-iii', '2014-07-09 11:15:27', '2014-07-09 11:15:27'),
(54, 'http://www.ruecker.org/', 'Incidunt voluptatem delectus magni at. Dicta aut nesciunt repellendus ut vel eius.\nQuam neque odio amet. Rerum ut et ex qui dolores quis nisi. At et asperiores voluptas cum aperiam est ipsa.', 'full', 2, 1, 'mr-lorenz-mcdermott-dvm', '2014-07-09 11:15:27', '2014-07-09 11:15:27'),
(55, 'http://parisian.com/', 'Quia ea minima nesciunt voluptas ipsum eum. Quaerat omnis dolorem corporis enim. Atque cum saepe voluptate hic est adipisci. Maxime et delectus veniam eaque est.', 'partial', 1, 1, 'presley-hackett', '2014-07-09 11:15:28', '2014-07-09 11:15:28'),
(56, 'http://www.corkery.net/', 'Tenetur qui corrupti cum porro vero. Magni quis autem id perferendis vero. Sequi non veritatis distinctio dolorem sequi recusandae repellendus. Autem veritatis architecto eaque itaque.', 'freelance', 1, 1, 'mrs-nathen-breitenberg-jr', '2014-07-09 11:15:28', '2014-07-09 11:15:28'),
(57, 'http://darechristiansen.org/', 'Molestiae quibusdam rerum aliquid dignissimos. Sunt asperiores quisquam deserunt tempora neque nostrum. Ad accusamus eaque eaque quam illum vel.', 'freelance', 2, 1, 'ms-haley-rosenbaum', '2014-07-09 11:15:28', '2014-07-09 11:15:28'),
(58, 'http://www.huelshahn.net/', 'Consectetur sint consequatur quia tenetur. Quo a molestiae velit vel id est quo. Est praesentium autem explicabo in in. Est laborum tempora facilis quidem rerum.', 'partial', 1, 1, 'herminia-rath-dds', '2014-07-09 11:15:28', '2014-07-09 11:15:28'),
(59, 'http://www.schillerkemmer.biz/', 'Velit dolor eum sint similique ut et culpa. Soluta dolores earum totam soluta sequi reprehenderit. Sint mollitia omnis ut ut in corrupti architecto.', 'full', 2, 1, 'zion-aufderhar-iii', '2014-07-09 11:15:29', '2014-07-09 11:15:29'),
(60, 'http://www.sporer.info/', 'Totam labore a quisquam voluptas dolorum. A ut quis velit dolorem dolorem. Aperiam consequatur qui inventore omnis. Eos quia tempore provident est.', 'full', 2, 1, 'ms-jazmyne-ortiz-dds', '2014-07-09 11:15:29', '2014-07-09 11:15:29'),
(61, 'http://www.conn.info/', 'Porro laborum corporis deserunt assumenda deserunt. Qui vel expedita sed dolore in quia eaque. Repudiandae a explicabo velit distinctio qui dolores aut labore. Ducimus totam rerum autem non neque.', 'partial', 2, 1, 'darian-feil-dvm', '2014-07-09 11:15:29', '2014-07-09 11:15:29'),
(62, 'http://www.mcclure.org/', 'Et voluptas ipsam voluptatem. Velit in qui nesciunt tempore aut. Modi aut molestiae dolor quibusdam eligendi quaerat. Qui amet nisi cumque repellat minima consequuntur quae.', 'partial', 3, 1, 'julia-ruecker', '2014-07-09 11:15:29', '2014-07-09 11:15:29'),
(63, 'http://www.pagacdaniel.com/', 'Ut sed et tempore et quisquam fuga. Sunt qui qui molestiae voluptatem eos modi esse sit. Doloremque labore praesentium recusandae deserunt.', 'partial', 1, 1, 'raymundo-carter', '2014-07-09 11:15:30', '2014-07-09 11:15:30'),
(64, 'http://ohara.net/', 'Alias officiis velit reiciendis. Dignissimos ut quaerat itaque illo id.', 'freelance', 1, 1, 'daren-wunsch-phd', '2014-07-09 11:15:30', '2014-07-09 11:15:30'),
(65, 'http://zulauf.com/', 'Voluptas officiis soluta vel sapiente alias nesciunt. Sit qui occaecati ipsam dolore et. Id impedit vitae deleniti omnis adipisci eius. Fugit iste dolorem sit numquam.', 'partial', 3, 1, 'dr-jerome-hayes', '2014-07-09 11:15:30', '2014-07-09 11:15:30'),
(66, 'http://oberbrunner.com/', 'Incidunt sunt et et officia dolore. Laudantium temporibus laboriosam error quo ullam. Voluptatibus odit et autem at.', 'freelance', 2, 1, 'bulah-ebert', '2014-07-09 11:15:30', '2014-07-09 11:15:30'),
(67, 'http://wyman.com/', 'Voluptatum explicabo voluptatem odio non. Suscipit aut iusto in impedit id laboriosam ea.', 'full', 2, 1, 'pansy-morissette-iii', '2014-07-09 11:15:30', '2014-07-09 11:15:30'),
(68, 'http://terry.com/', 'Numquam voluptatem odit quo officia dolorum. Aperiam dignissimos similique blanditiis quis. Recusandae esse in similique.', 'partial', 3, 1, 'kasey-durgan', '2014-07-09 11:15:31', '2014-07-09 11:15:31'),
(69, 'http://hills.com/', 'Numquam enim a ratione voluptatem impedit. Ratione possimus alias libero omnis consequuntur fuga dolorem. Doloribus cum est tenetur porro et.', 'full', 3, 1, 'miss-laurine-sporer-iii', '2014-07-09 11:15:31', '2014-07-09 11:15:31'),
(70, 'http://veum.com/', 'Maxime pariatur et velit. Aliquid vel nesciunt rerum. Laborum nam veritatis est. Est perferendis reiciendis aut porro reiciendis est ab.', 'full', 3, 1, 'meredith-boyer-dds', '2014-07-09 11:15:31', '2014-07-09 11:15:31'),
(71, 'http://www.schusterfeest.info/', 'At provident consequatur voluptas. Est aperiam dolorem odit tempore voluptatem suscipit quibusdam. Quo rerum a quia voluptatum vitae in aperiam. Quae totam quaerat maxime.', 'full', 2, 1, 'rachel-vandervort', '2014-07-09 11:15:31', '2014-07-09 11:15:31'),
(72, 'http://www.sanfordlowe.com/', 'Libero quae dolor aut eum dolor corporis. Et tempora sint doloremque necessitatibus omnis magnam. Laborum animi ad voluptas impedit soluta.', 'full', 1, 1, 'prince-wehner', '2014-07-09 11:15:32', '2014-07-09 11:15:32'),
(73, 'http://www.erdmancassin.com/', 'Nobis aut maxime officia eligendi illo harum et. Similique vitae dolor et rerum repudiandae.', 'freelance', 1, 1, 'vanessa-hudson', '2014-07-09 11:15:32', '2014-07-09 11:15:32'),
(74, 'http://goodwin.com/', 'Eius voluptatibus sint eos expedita est. Et sit dolor sed veritatis earum ipsam reiciendis. Ea optio voluptatum cupiditate eveniet ut. Voluptas ad quisquam laboriosam vitae facilis.', 'freelance', 1, 1, 'unique-homenick-sr', '2014-07-09 11:15:32', '2014-07-09 11:15:32'),
(75, 'http://www.ledner.com/', 'Dolores saepe commodi natus accusantium quidem nam. Nam sunt harum nam accusantium veniam enim.', 'full', 2, 1, 'paxton-cole', '2014-07-09 11:15:33', '2014-07-09 11:15:33'),
(76, 'http://leuschke.com/', 'Ipsa dolor ratione sed illo voluptatem iste amet. Voluptas voluptatem iusto aut iste. Ut architecto autem et ea. Aut voluptate iusto ut similique aut in accusantium.', 'partial', 1, 1, 'alex-schneider', '2014-07-09 11:15:33', '2014-07-09 11:15:33'),
(77, 'http://www.waelchiryan.biz/', 'Porro exercitationem dolorum eveniet nam non sed illo. Aut ratione eum et. Et facere aperiam enim.\nVoluptatem recusandae eligendi eos. Sapiente ut mollitia voluptas porro libero nobis.', 'full', 3, 1, 'dr-alfonzo-stoltenberg-md', '2014-07-09 11:15:33', '2014-07-09 11:15:33'),
(78, 'http://www.reingernitzsche.com/', 'Nulla quibusdam eos sunt dolor voluptatum quae blanditiis. Quo molestiae dignissimos sit doloribus. Debitis et at ea eum earum. Ea perferendis dolorem beatae quis eveniet.', 'full', 1, 1, 'ms-maryjane-considine-jr', '2014-07-09 11:15:33', '2014-07-09 11:15:33'),
(79, 'http://aufderhar.biz/', 'Ut alias voluptatum deserunt id ut. Quod quidem aperiam iure adipisci. Et doloribus quia provident commodi inventore numquam eum in. Quibusdam officiis cumque ab at neque eum est.', 'freelance', 1, 1, 'carter-schneider', '2014-07-09 11:15:33', '2014-07-09 11:15:33'),
(80, 'http://www.halvorson.com/', 'Sit labore iste temporibus aut vitae. Dolorem ut quia velit excepturi sit rem. Tenetur nisi corporis omnis et laborum corrupti. Autem odit repudiandae praesentium expedita amet.', 'freelance', 2, 1, 'maritza-armstrong', '2014-07-09 11:15:34', '2014-07-09 11:15:34');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Backend Developers', 'backend-developers', '2014-07-09 11:15:12', '2014-07-09 11:15:12'),
(2, 'Frontend Developers', 'frontend-developers', '2014-07-09 11:15:13', '2014-07-09 11:15:13'),
(3, 'Designers', 'designers', '2014-07-09 11:15:13', '2014-07-09 11:15:13');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_07_08_034010_create_users_table', 1),
('2014_07_08_040014_create_categories_table', 1),
('2014_07_08_040512_create_candidates_table', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `type` enum('admin','candidate') NOT NULL,
  `remember_token` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=81 ;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `password`, `type`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Dr. Kellen Kovacek V', 'dietrich.kiana@yahoo.com', '$2y$10$9nGmi7eD8CgvnVFmO407BeW2aJ8GpcpxyJ.t00tD/27wty07fEhl.', 'candidate', NULL, '2014-07-09 11:15:13', '2014-07-09 11:15:13'),
(2, 'Karianne Smith MD', 'dana93@mann.info', '$2y$10$lnIaLlUP7gR9dyZ6sEV9/.3fR94tHXh8qxGh9yiw.s1jWGGxq3RT.', 'candidate', NULL, '2014-07-09 11:15:13', '2014-07-09 11:15:13'),
(3, 'Tremaine Jacobson', 'jayce.huels@gottlieb.com', '$2y$10$wOXWisHODocoTnkdRSY1wOrFvbNt1lL3i2v5BiWQHdUwdMxiRr5p2', 'candidate', NULL, '2014-07-09 11:15:14', '2014-07-09 11:15:14'),
(4, 'Ms. Minnie Brakus DDS', 'marc.boyle@gmail.com', '$2y$10$L8MBF0jofDKUvw.woM6Xcuq7pb1Ltw5avJnubV8VFtItciNdFwCF2', 'candidate', NULL, '2014-07-09 11:15:14', '2014-07-09 11:15:14'),
(5, 'Ms. Jay Marvin', 'fay.oma@gmail.com', '$2y$10$lwPD7O00/d0tJtvogzH38u/C4i7O5irIZ.L7WXTVbMMRZfVTZaf5i', 'candidate', NULL, '2014-07-09 11:15:14', '2014-07-09 11:15:14'),
(6, 'Mrs. Walker Metz V', 'reyes.heathcote@gmail.com', '$2y$10$BGHc0u5GPqNXC..lmokMpu9gu982ez/kUy/r39T7ejmUND22nacO2', 'candidate', NULL, '2014-07-09 11:15:15', '2014-07-09 11:15:15'),
(7, 'Chandler Champlin', 'liliane88@hotmail.com', '$2y$10$PMaOogOsOuEmuEQyfTxuyub7v3hhdcaUH/9icYDdzDRcmEAd39cSy', 'candidate', NULL, '2014-07-09 11:15:15', '2014-07-09 11:15:15'),
(8, 'Aric Ritchie V', 'carolyn.marvin@tillmanprosacco.com', '$2y$10$FuVR4S6u8b3eWbdwNBkpWeicifcJu3f7l.STLqAgYFkOCE.EoOCCi', 'candidate', NULL, '2014-07-09 11:15:15', '2014-07-09 11:15:15'),
(9, 'Isai Hamill', 'mckenzie56@yahoo.com', '$2y$10$xarbY0x2/gt.DRkGC1ATCOA/Y/1Fm3geEeYmzK9x/WbybsVg6yk7q', 'candidate', NULL, '2014-07-09 11:15:16', '2014-07-09 11:15:16'),
(10, 'Miss Bradley Witting Sr.', 'alize.lubowitz@yahoo.com', '$2y$10$2iF3gIBAFSEZlcJKj2b8N.BN2t0s6CU9lkBwkm668rQgw2WKWms16', 'candidate', NULL, '2014-07-09 11:15:16', '2014-07-09 11:15:16'),
(11, 'Mollie Baumbach', 'reinhold.rau@hotmail.com', '$2y$10$d9nrhteYE5JLqiZINXWcj.By3fdKDRyxFjBXCkqkUpLd5fDMZMObS', 'candidate', NULL, '2014-07-09 11:15:16', '2014-07-09 11:15:16'),
(12, 'Keaton Graham', 'conner.metz@hotmail.com', '$2y$10$Mqk5vPDbpXkXd3Zjc5qH6eYEs09HFF4rmqGbxH1pbKzya4PqY6pLi', 'candidate', NULL, '2014-07-09 11:15:16', '2014-07-09 11:15:16'),
(13, 'Houston Bayer', 'rickie14@yahoo.com', '$2y$10$OYsuDrQN/IvsbzeBi8qNDuCm4GXIMyVkqHkx4nds1NoPiPf6cIUny', 'candidate', NULL, '2014-07-09 11:15:17', '2014-07-09 11:15:17'),
(14, 'Victoria Waters', 'qjacobson@hamilldibbert.biz', '$2y$10$hHUZBtF2RPVnBU0mpqC5r.IrfShQmUFKKsu.XTtwxjwO8eaQvcfP2', 'candidate', NULL, '2014-07-09 11:15:17', '2014-07-09 11:15:17'),
(15, 'Dr. Javon Johns', 'marisa.romaguera@yahoo.com', '$2y$10$6e35kja73hcq/o3Fvm4gUeX322fznTttE4UXZ7GLJ65MfAKXmByM2', 'candidate', NULL, '2014-07-09 11:15:17', '2014-07-09 11:15:17'),
(16, 'Annabel Cummings', 'sheidenreich@harvey.info', '$2y$10$6gN9tkPWtSBp.WfikgNuPewPRc6cr4EpO1bu24dmQMcklF2BAuOqK', 'candidate', NULL, '2014-07-09 11:15:17', '2014-07-09 11:15:17'),
(17, 'Onie Erdman Jr.', 'adrian.kautzer@harberjakubowski.com', '$2y$10$dS47L4VAFCqv7/qVkr5KWu6zPycQARC1YXBg2FhmrenXabBly0vny', 'candidate', NULL, '2014-07-09 11:15:18', '2014-07-09 11:15:18'),
(18, 'Rosetta Legros', 'eugene.mckenzie@willmskoepp.info', '$2y$10$qPXBYSsSWvx.bxKfEyVsm.LNCMHD8TzsrE6KoPNYzPgnxJZsxOhuy', 'candidate', NULL, '2014-07-09 11:15:18', '2014-07-09 11:15:18'),
(19, 'Mr. Jeffery Sanford DDS', 'kohler.shanon@gmail.com', '$2y$10$Ar1nlucrMGMnVQ6KMg1k5OB23tg0xBh6RPwGQr3CHRgbSRC1CIrYS', 'candidate', NULL, '2014-07-09 11:15:18', '2014-07-09 11:15:18'),
(20, 'Norbert Koepp', 'rosamond52@millshayes.com', '$2y$10$29/7LplvQgqqJP2hvaxYOePnPlbFWUsfu0IHbbvXsM1YpeBd204XC', 'candidate', NULL, '2014-07-09 11:15:18', '2014-07-09 11:15:18'),
(21, 'Misael Murray I', 'myah64@gmail.com', '$2y$10$gtzTkjmUiqBX7L3kYux4oOf77b5p7EL40oa8JWBXGleiOchJaLZ7a', 'candidate', NULL, '2014-07-09 11:15:19', '2014-07-09 11:15:19'),
(22, 'Dr. Shaina Wunsch V', 'lrunolfsson@gmail.com', '$2y$10$u.ltKrGv.VmmvGWOChXkOu3lfQUXlDWqcuuolat8ldgfla/JjpsXy', 'candidate', NULL, '2014-07-09 11:15:19', '2014-07-09 11:15:19'),
(23, 'London Blick', 'bradford.fay@homenick.com', '$2y$10$qlek6wS.8kIG.HNJn9Jj2e0yRCJmbz1TYhMT/1AVfgxCjDWL/Ynqa', 'candidate', NULL, '2014-07-09 11:15:19', '2014-07-09 11:15:19'),
(24, 'Mr. Janis Spencer V', 'moen.dorian@yahoo.com', '$2y$10$2wUtlDgedR5eR9XWYJfWVea5vEdiey2bzeK58zIhJuY.P7u90sybq', 'candidate', NULL, '2014-07-09 11:15:19', '2014-07-09 11:15:19'),
(25, 'Ms. Jamel Sipes V', 'hermann.reyes@cronaschaefer.com', '$2y$10$AUaJxIFoqMsCojux73Mi9.y0Ni6wcnzPvDrH8aqtuj48jcF.hBTPC', 'candidate', NULL, '2014-07-09 11:15:20', '2014-07-09 11:15:20'),
(26, 'Moses Schaden', 'marilou82@hotmail.com', '$2y$10$1erE5jreBiMe1LTS5Ve8DOqbQe1CfIEwVlrIZS33p2Gw.IPZDBps6', 'candidate', NULL, '2014-07-09 11:15:20', '2014-07-09 11:15:20'),
(27, 'Geovanny Pacocha', 'jevon15@vandervorthalvorson.com', '$2y$10$vF0PjArSJy2FowcIvVGHi.Qne0a2.3mHqLpLowxxSNGXvoO8c/SM2', 'candidate', NULL, '2014-07-09 11:15:20', '2014-07-09 11:15:20'),
(28, 'Miss Celestino Pacocha II', 'moen.norval@torphybrown.com', '$2y$10$WtdBtXxhI/.Z7S4k9rQt/uXBWo1653smWBeVliXIgkYh.m5Fr4QXu', 'candidate', NULL, '2014-07-09 11:15:20', '2014-07-09 11:15:20'),
(29, 'Karina Kessler MD', 'jaskolski.danika@gmail.com', '$2y$10$YD9wJNS1T8IzIfEzvB6qqO.B/SxdDV2v6Yi2CE8igSPDILSRbA8iC', 'candidate', NULL, '2014-07-09 11:15:21', '2014-07-09 11:15:21'),
(30, 'Franz Schumm', 'tremblay.eunice@yahoo.com', '$2y$10$nMt/WkRrKl8CMweh4GirY.fikdspAUyQD6WughIWX/HPFCscOGzf6', 'candidate', NULL, '2014-07-09 11:15:21', '2014-07-09 11:15:21'),
(31, 'Paul Borer Sr.', 'malinda.bashirian@gislason.com', '$2y$10$rdja040LWMKvvSEQIbPFPu9FFx9SgBIDI9WIYGaNMHQHtW94H6VwO', 'candidate', NULL, '2014-07-09 11:15:21', '2014-07-09 11:15:21'),
(32, 'Dr. Hassie Herman', 'johnston.charity@gmail.com', '$2y$10$lYwW0UxWDhUkcU7Fsc1pteLXzRsG25qycw.r5lYESjldtWdcy1QP6', 'candidate', NULL, '2014-07-09 11:15:21', '2014-07-09 11:15:21'),
(33, 'Franco Roberts', 'mante.hertha@gmail.com', '$2y$10$oOIDAGppOyHo4xZGA7c0U.CxyWtwkWjE6.udyVWJ1a90ETy1y/t.G', 'candidate', NULL, '2014-07-09 11:15:22', '2014-07-09 11:15:22'),
(34, 'Pansy Reilly', 'dwisozk@gmail.com', '$2y$10$4IU7GJUDDtQwsYW3oBYFouLF17T7lQTjLM9q9nJhxCBbrFzsIdBBO', 'candidate', NULL, '2014-07-09 11:15:22', '2014-07-09 11:15:22'),
(35, 'Giovanny Swaniawski', 'hessel.jaquan@bruenmcglynn.com', '$2y$10$y9N/i4EMwW1C20loQBJcIORlHpdL163KIb1hfvLs6JUHWkN4ecWPS', 'candidate', NULL, '2014-07-09 11:15:22', '2014-07-09 11:15:22'),
(36, 'Alfred Berge', 'regan59@gmail.com', '$2y$10$G04p3zVM7.LIWzK2wA332OFFgAkqnQwBlhRrZqrWek1d2lfcugZGC', 'candidate', NULL, '2014-07-09 11:15:22', '2014-07-09 11:15:22'),
(37, 'Maegan Ryan', 'savanah.reichert@heaney.com', '$2y$10$/1Ytfyv1HoeTQrrKGGF6OeL5w248dsdXSqG4MVw1ycw22EQYOkW8m', 'candidate', NULL, '2014-07-09 11:15:23', '2014-07-09 11:15:23'),
(38, 'Ms. Kristian Wolff III', 'batz.rocio@hotmail.com', '$2y$10$lg.hQP3hAeUDTytDYP3dN.OEVR38IFmOogqG4Djr.pTZ7ce9yxIWm', 'candidate', NULL, '2014-07-09 11:15:23', '2014-07-09 11:15:23'),
(39, 'Adonis Kunde', 'miller.rolando@gmail.com', '$2y$10$mvrIbNlOpI0lIZpGY8KIVukSZKLIuzEcMC1yqUZ8F09ZHd.G4Ay7G', 'candidate', NULL, '2014-07-09 11:15:23', '2014-07-09 11:15:23'),
(40, 'Jordi Crona', 'tromp.darrion@schmitt.com', '$2y$10$tiHO260LELBtm1dGrVu/Ae5ee9slWRiNqKJSs6fIpu9I0094DxtTy', 'candidate', NULL, '2014-07-09 11:15:24', '2014-07-09 11:15:24'),
(41, 'Mrs. Reyna Beahan', 'jerrold45@hansenbernhard.com', '$2y$10$ZtsH8W0Z9DQW0lwqHK9f1OeeAxWgSeZV5RnNtFwXAanRCuzsWtMqy', 'candidate', NULL, '2014-07-09 11:15:24', '2014-07-09 11:15:24'),
(42, 'Blake Morar', 'hledner@gmail.com', '$2y$10$CowmSLSOnvLZ/3eCcwxc5eirJSiqM8.znjGSm3z8rofNwz5nQKbBW', 'candidate', NULL, '2014-07-09 11:15:24', '2014-07-09 11:15:24'),
(43, 'Golden Dach Jr.', 'dion.abbott@hotmail.com', '$2y$10$yMMEISNOWZVseh.KCAaZlefVvov/aGbyf7gU7IuL5jaIh1CfG1Qk.', 'candidate', NULL, '2014-07-09 11:15:24', '2014-07-09 11:15:24'),
(44, 'Vern Davis', 'rigoberto.grady@nienow.info', '$2y$10$faJA2InbfmvBPcEXzW2xsO4XO.IP/kBSgqtufPR7IqfOiew2lD19G', 'candidate', NULL, '2014-07-09 11:15:25', '2014-07-09 11:15:25'),
(45, 'Taurean Metz', 'legros.dolores@hotmail.com', '$2y$10$AyMvcqZx07ybKJ4Znxf0muMqSxrC1Ybjqbgq.aybRzm2rwrdNMk4S', 'candidate', NULL, '2014-07-09 11:15:25', '2014-07-09 11:15:25'),
(46, 'Mr. Chadrick O''Hara', 'kayden.spinka@hotmail.com', '$2y$10$/mTFLSFqIMGhOS6I7cDzUeDgsMloTrkA8KJF0HOuZ8r0q5a.57706', 'candidate', NULL, '2014-07-09 11:15:25', '2014-07-09 11:15:25'),
(47, 'Dr. Adelle Funk', 'odubuque@lakin.com', '$2y$10$a18nIFD7MswF0u5xdJt7GuJlwITl1G8YgiAbidAKQzGY0AiIRKnga', 'candidate', NULL, '2014-07-09 11:15:26', '2014-07-09 11:15:26'),
(48, 'Lillian Witting', 'strosin.matilde@walter.com', '$2y$10$cj/bm4tBy9XrPCVWkJnU1.mff5LY4BxNyX03bDabzvzhAW3ZGybx2', 'candidate', NULL, '2014-07-09 11:15:26', '2014-07-09 11:15:26'),
(49, 'Sharon Eichmann', 'erika52@swift.info', '$2y$10$fPevjXYxkOpB8dE4XK5y0.drcC1HwGDimlmZakRuKs6CN7xTO77j2', 'candidate', NULL, '2014-07-09 11:15:26', '2014-07-09 11:15:26'),
(50, 'Dr. Charity Towne', 'lind.greg@yahoo.com', '$2y$10$1EElsPMLjCE2fuRoUxQqYO3hlVFy7LWItJx14BBRCPYlZGikShKTq', 'candidate', NULL, '2014-07-09 11:15:26', '2014-07-09 11:15:26'),
(51, 'Hortense Murphy', 'tristian03@yahoo.com', '$2y$10$BYxh.GP1.7fOovNpDoOZPOW6Sr6nPur7VIlxUIPHMURgwGKzXgdra', 'candidate', NULL, '2014-07-09 11:15:27', '2014-07-09 11:15:27'),
(52, 'Elmer Windler', 'mike61@mosciskiokon.info', '$2y$10$8QIJYcbSHLUfvgwSeLnp1er6XZuT3GYGIfoGyAzMzhjBvff.PxyiC', 'candidate', NULL, '2014-07-09 11:15:27', '2014-07-09 11:15:27'),
(53, 'Jefferey Schinner III', 'rath.deshawn@hotmail.com', '$2y$10$fdF5.6hHQyTzm.ij0LgOSupF.JNrFUUKcfynFVh17XdcENdHuZwAy', 'candidate', NULL, '2014-07-09 11:15:27', '2014-07-09 11:15:27'),
(54, 'Mr. Lorenz McDermott DVM', 'bartell.austyn@hotmail.com', '$2y$10$wgAhvXJX4sXcll.wFjMNrumOBnmvIaXFDNn4LZjzIRPLxZcq8sbBq', 'candidate', NULL, '2014-07-09 11:15:27', '2014-07-09 11:15:27'),
(55, 'Presley Hackett', 'russ33@hotmail.com', '$2y$10$W.QgWGj8m4gSPuO6wZ0wd.lVsGEu8A.KTNszkXgjU4WZwTr8e3S6a', 'candidate', NULL, '2014-07-09 11:15:28', '2014-07-09 11:15:28'),
(56, 'Mrs. Nathen Breitenberg Jr.', 'knicolas@nitzsche.com', '$2y$10$JqWNJj2pjAkb4wrIcke4WOJ5Bf9DYnVHc0Zn.G0nj.Po0U8cNNOEC', 'candidate', NULL, '2014-07-09 11:15:28', '2014-07-09 11:15:28'),
(57, 'Ms. Haley Rosenbaum', 'julie34@upton.org', '$2y$10$LI7X6aVyj8fdqT.bEeYs7uRWH6DdZdEfiskgVGp9cq4uDwaKmvrLa', 'candidate', NULL, '2014-07-09 11:15:28', '2014-07-09 11:15:28'),
(58, 'Herminia Rath DDS', 'pkertzmann@yahoo.com', '$2y$10$T1ISaT6BKELChn1z0JG1dOEQ6QWpEbaOpgSTzYadrVNV3iMQk0Cx2', 'candidate', NULL, '2014-07-09 11:15:28', '2014-07-09 11:15:28'),
(59, 'Zion Aufderhar III', 'fsporer@nitzscherolfson.info', '$2y$10$C0KYFXbHGIOv6mtZ6pymaeYc4YOho6LkJxY8.6o9MrEiEL5uZ6r3G', 'candidate', NULL, '2014-07-09 11:15:28', '2014-07-09 11:15:28'),
(60, 'Ms. Jazmyne Ortiz DDS', 'omiller@yahoo.com', '$2y$10$g8LOXGOZcFvWdKofOHhDc.TW78bKp9dvnYtFmZNFh0BVzOst6Bpoi', 'candidate', NULL, '2014-07-09 11:15:29', '2014-07-09 11:15:29'),
(61, 'Darian Feil DVM', 'bailee.hettinger@schumm.com', '$2y$10$x8xQqvyUbjGsfjdvL71e1uE1a.VQd30lehSJwwx3o0ty2y.gB3jr6', 'candidate', NULL, '2014-07-09 11:15:29', '2014-07-09 11:15:29'),
(62, 'Julia Ruecker', 'fay.mozell@yahoo.com', '$2y$10$6jQ.mGzqKA7BRufvwe6aR.1MnoTOP1YD6fviryjmml/eEzSjfCzFi', 'candidate', NULL, '2014-07-09 11:15:29', '2014-07-09 11:15:29'),
(63, 'Raymundo Carter', 'pgoyette@hotmail.com', '$2y$10$Lcxf1eSCJUONMSrBz/kAYu0wagdoPjVo4ROJDztzThPYpOMi8TFYC', 'candidate', NULL, '2014-07-09 11:15:30', '2014-07-09 11:15:30'),
(64, 'Daren Wunsch PhD', 'ryann.kemmer@hesselgleichner.biz', '$2y$10$rm/8pOuhRkeeIIwvIch4RuAsSLyFklQrqa5wHx7xGmqYC7S23pgYG', 'candidate', NULL, '2014-07-09 11:15:30', '2014-07-09 11:15:30'),
(65, 'Dr. Jerome Hayes', 'dietrich.marlee@hotmail.com', '$2y$10$MHPjfIzj7lpvL6HwDw4fk.I9umeMjvnsNyvhIgmmfVm4YWchVA.bm', 'candidate', NULL, '2014-07-09 11:15:30', '2014-07-09 11:15:30'),
(66, 'Bulah Ebert', 'jasmin.lakin@yahoo.com', '$2y$10$fOi/69CwBf.POszsf3DGiewDRXBmYPYBYPeITligoJnIgiyaZEzWK', 'candidate', NULL, '2014-07-09 11:15:30', '2014-07-09 11:15:30'),
(67, 'Pansy Morissette III', 'francisca52@yahoo.com', '$2y$10$/TibKjOoXdxPfEW3voFFUeOBI9tsX7h2eVEgyxBx4CiN0RZYlPS8O', 'candidate', NULL, '2014-07-09 11:15:30', '2014-07-09 11:15:30'),
(68, 'Kasey Durgan', 'grady.savanna@hermann.com', '$2y$10$U71lAO6JOLUFsIjhP6ZiT.xo1eJs5W6gnu2cUxXnPJYiXvJfjSKka', 'candidate', NULL, '2014-07-09 11:15:31', '2014-07-09 11:15:31'),
(69, 'Miss Laurine Sporer III', 'nathanael.rau@gmail.com', '$2y$10$9zJJqj6AOhw5EFxxYLgQoertL3gz/G6n343lnOFJCkGGKZT0MzhPi', 'candidate', NULL, '2014-07-09 11:15:31', '2014-07-09 11:15:31'),
(70, 'Meredith Boyer DDS', 'mohr.eryn@block.org', '$2y$10$SS/BIj/8sIEiP9sYd1w.LO2n4odVqpTFTNG.QlDz3ibvlcaoxFzP2', 'candidate', NULL, '2014-07-09 11:15:31', '2014-07-09 11:15:31'),
(71, 'Rachel Vandervort', 'paucek.daphnee@lefflerstiedemann.org', '$2y$10$KuFPG91lB1ihe15Iy1sUM.3snpEvCxN..XPIGhuk0YFJEZ/VnnFQ6', 'candidate', NULL, '2014-07-09 11:15:31', '2014-07-09 11:15:31'),
(72, 'Prince Wehner', 'jeffrey97@ortiz.com', '$2y$10$8dtKqqOR9S43JM14LmNe1O/Yv92pz/fsF2M/6uBsxAhUo4P80Z7x6', 'candidate', NULL, '2014-07-09 11:15:32', '2014-07-09 11:15:32'),
(73, 'Vanessa Hudson', 'noe80@yahoo.com', '$2y$10$A1rYfCNdjUGD1epeWC5Ik.BoUMdWbEOdrRmGJd71SHIZYL6WMPs5C', 'candidate', NULL, '2014-07-09 11:15:32', '2014-07-09 11:15:32'),
(74, 'Unique Homenick Sr.', 'rhuels@yahoo.com', '$2y$10$xuNJQtvZfUaCfcgkCSNvEu4wa75FKm/otNB8FLwMfyzmXI2HnAVUS', 'candidate', NULL, '2014-07-09 11:15:32', '2014-07-09 11:15:32'),
(75, 'Paxton Cole', 'idella.ritchie@gmail.com', '$2y$10$fc.RBu.plLbt1xicYx/lEOezIl3v1ur5izHngnbvyVoZptzfeqh8m', 'candidate', NULL, '2014-07-09 11:15:32', '2014-07-09 11:15:32'),
(76, 'Alex Schneider', 'ben05@haaglueilwitz.com', '$2y$10$IJbg8kIHLl9gCj4uT0/3LekT0HKQT5GRFEYfqmkDZKz239vAmuspe', 'candidate', NULL, '2014-07-09 11:15:33', '2014-07-09 11:15:33'),
(77, 'Dr. Alfonzo Stoltenberg MD', 'audie.lockman@hotmail.com', '$2y$10$kl1rnSLlDVghOqpf.VxU..QKcF4YrViqfUA.HWfNC1jo9AAErc.vK', 'candidate', NULL, '2014-07-09 11:15:33', '2014-07-09 11:15:33'),
(78, 'Ms. Maryjane Considine Jr.', 'clarissa.auer@mitchell.com', '$2y$10$lblb872EpF7StjxQghgS7u1lPlSkRx75dJRpX1MMr/BVk1q/ge0Qi', 'candidate', NULL, '2014-07-09 11:15:33', '2014-07-09 11:15:33'),
(79, 'Carter Schneider', 'casper.seth@hotmail.com', '$2y$10$C.S1mtIHFUQKz3wsnqMiuuq8N7xUJGzI1OkkuB8nRkXYaLBCvTCf2', 'candidate', NULL, '2014-07-09 11:15:33', '2014-07-09 11:15:33'),
(80, 'Maritza Armstrong', 'gianni57@cummerata.org', '$2y$10$20Z1T/B8a9/.oJvWOtCdYejcFDjUSz3JnxQxdW7XZph6Mof/56VdW', 'candidate', NULL, '2014-07-09 11:15:34', '2014-07-09 11:15:34');

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `candidates`
--
ALTER TABLE `candidates`
  ADD CONSTRAINT `candidates_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
